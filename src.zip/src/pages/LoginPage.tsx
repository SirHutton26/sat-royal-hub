import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Navigate } from 'react-router-dom'
import { Mail, Lock, Eye, EyeOff, ShieldAlert, X } from 'lucide-react'
import { useAuth } from '@/features/auth/AuthProvider'
import schoolLogo from '@/assets/school-logo.png'

const loginSchema = z.object({
  email: z.string().trim().min(1, 'Email is required').email('Enter a valid email address'),
  password: z.string().min(1, 'Password is required').min(6, 'Password must be at least 6 characters'),
})

type LoginFormValues = z.infer<typeof loginSchema>

function BrandHeading() {
  return (
    <h1 className="flex items-center justify-center text-3xl font-bold tracking-wide text-white">
      <span>SAT ROYAL H</span>
      <span className="relative inline-block">
        U
        <svg
          viewBox="0 0 24 24"
          className="absolute -right-2 -top-3 h-4 w-4 text-gold-400"
          fill="currentColor"
          aria-hidden="true"
        >
          <path d="M12 1a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2h-1V6a5 5 0 0 0-5-5Zm-3 8V6a3 3 0 0 1 6 0v3H9Zm3 4a1.5 1.5 0 0 1 1 2.6V18a1 1 0 1 1-2 0v-2.4A1.5 1.5 0 0 1 12 13Z" />
        </svg>
      </span>
      <span>B</span>
    </h1>
  )
}

function LoadingOverlay() {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-royal-900/40 backdrop-blur-sm">
      <div className="relative flex h-24 w-24 items-center justify-center">
        <span className="absolute inset-0 animate-spin rounded-full border-4 border-gold-400 border-t-transparent" />
        <img src={schoolLogo} alt="" className="h-16 w-16 rounded-full bg-white object-contain p-1" />
      </div>
      <p className="mt-4 text-sm font-medium text-white">Signing in...</p>
    </div>
  )
}

function ForgotPasswordNotice({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-royal-900/40 px-4">
      <div className="relative w-full max-w-sm rounded-xl bg-white p-6 shadow-lg">
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
        >
          <X className="h-5 w-5" />
        </button>
        <ShieldAlert className="h-8 w-8 text-royal-600" />
        <h2 className="mt-3 text-lg font-semibold text-royal-900">Reset your password</h2>
        <p className="mt-2 text-sm text-gray-600">
          For account security, password resets are handled by your school administrator.
          Please contact them directly to have your password reset.
        </p>
        <button
          onClick={onClose}
          className="mt-5 w-full rounded-md bg-royal-600 py-2 text-sm font-semibold text-white hover:bg-royal-700"
        >
          Got it
        </button>
      </div>
    </div>
  )
}

export default function LoginPage() {
  const { profile, signIn } = useAuth()
  const [showPassword, setShowPassword] = useState(false)
  const [showForgot, setShowForgot] = useState(false)
  const [authError, setAuthError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormValues>({ resolver: zodResolver(loginSchema) })

  if (profile?.is_active) {
    return <Navigate to={profile.role === 'admin' ? '/admin' : '/teacher'} replace />
  }

  async function onSubmit(values: LoginFormValues) {
    setBusy(true)
    setAuthError(null)
    const err = await signIn(values.email, values.password)
    if (err) setAuthError(err)
    setBusy(false)
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-royal-600 px-4">
      <BrandHeading />
      <div className="mt-3 h-1 w-24 rounded bg-gold-400" />

      <form
        onSubmit={handleSubmit(onSubmit)}
        noValidate
        className="mt-8 w-full max-w-sm rounded-xl bg-white p-6 shadow-lg"
      >
        <h2 className="text-lg font-semibold text-royal-900">Sign in</h2>

        <div className="mt-4">
          <label htmlFor="email" className="block text-sm font-medium text-royal-900">
            Email
          </label>
          <div className="relative mt-1">
            <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              id="email"
              type="email"
              autoComplete="username"
              placeholder="you@school.edu"
              aria-invalid={!!errors.email}
              {...register('email')}
              className={`w-full rounded-lg border py-2 pl-10 pr-3 text-sm outline-none transition focus:ring-2 ${
                errors.email
                  ? 'border-red-400 focus:border-red-500 focus:ring-red-100'
                  : 'border-gray-300 focus:border-royal-500 focus:ring-royal-100'
              }`}
            />
          </div>
          {errors.email && <p className="mt-1 text-xs text-red-600">{errors.email.message}</p>}
        </div>

        <div className="mt-4">
          <label htmlFor="password" className="block text-sm font-medium text-royal-900">
            Password
          </label>
          <div className="relative mt-1">
            <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              id="password"
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              placeholder="••••••••"
              aria-invalid={!!errors.password}
              {...register('password')}
              className={`w-full rounded-lg border py-2 pl-10 pr-10 text-sm outline-none transition focus:ring-2 ${
                errors.password
                  ? 'border-red-400 focus:border-red-500 focus:ring-red-100'
                  : 'border-gray-300 focus:border-royal-500 focus:ring-royal-100'
              }`}
            />
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              aria-label={showPassword ? 'Hide password' : 'Show password'}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          {errors.password && <p className="mt-1 text-xs text-red-600">{errors.password.message}</p>}
        </div>

        <div className="mt-3 text-right">
          <button
            type="button"
            onClick={() => setShowForgot(true)}
            className="text-xs font-medium text-royal-600 hover:text-royal-700 hover:underline"
          >
            Forgot password?
          </button>
        </div>

        {authError && (
          <p className="mt-3 rounded-md bg-red-50 px-3 py-2 text-sm text-red-600">{authError}</p>
        )}

        <button
          type="submit"
          disabled={busy}
          className="mt-5 w-full rounded-md bg-royal-600 py-2 font-semibold text-white transition hover:bg-royal-700 disabled:opacity-60"
        >
          Sign in
        </button>
      </form>

      {busy && <LoadingOverlay />}
      {showForgot && <ForgotPasswordNotice onClose={() => setShowForgot(false)} />}
    </div>
  )
}