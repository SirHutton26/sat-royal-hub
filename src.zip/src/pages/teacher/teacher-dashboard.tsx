import { useEffect, useState } from 'react'
import { Users, GraduationCap, HelpCircle, FileText, ClipboardList, CalendarCheck2 } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/features/auth/AuthProvider'

const COMING_SOON_ITEMS = [
  { label: 'Quiz', icon: HelpCircle },
  { label: 'Exams', icon: FileText },
  { label: 'SBA', icon: ClipboardList },
  { label: 'Staff Attendance', icon: CalendarCheck2 },
]

export default function TeacherDashboard() {
  const { profile } = useAuth()
  const [className, setClassName] = useState<string | null>(null)
  const [studentCount, setStudentCount] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true

    async function load() {
      if (!profile) return
      const { data: myClass } = await supabase
        .from('classes')
        .select('id, name')
        .eq('teacher_id', profile.id)
        .maybeSingle()

      if (!active) return

      if (myClass) {
        setClassName(myClass.name)
        const { count } = await supabase
          .from('students')
          .select('id', { count: 'exact', head: true })
          .eq('class_id', myClass.id)
          .eq('is_active', true)
        if (active) setStudentCount(count ?? 0)
      }
      setLoading(false)
    }

    load()
    return () => {
      active = false
    }
  }, [profile])

  return (
    <div>
      <div className="rounded-xl bg-gradient-to-r from-royal-600 to-royal-700 p-6 text-white shadow-sm">
        <h1 className="text-xl font-semibold">
          Welcome, {profile?.full_name || profile?.email}
        </h1>
        <p className="mt-1 text-sm text-royal-100">Here's your SAT ROYAL HUB overview.</p>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl bg-white p-4 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-royal-50 p-2.5 text-royal-600">
              <GraduationCap className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs text-gray-500">My class</p>
              {loading ? (
                <div className="mt-1 h-6 w-16 animate-pulse rounded bg-gray-200" />
              ) : (
                <p className="text-lg font-bold text-royal-900">{className || 'Unassigned'}</p>
              )}
            </div>
          </div>
        </div>

        <div className="rounded-xl bg-white p-4 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-green-50 p-2.5 text-green-600">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs text-gray-500">Students</p>
              {loading ? (
                <div className="mt-1 h-6 w-10 animate-pulse rounded bg-gray-200" />
              ) : (
                <p className="text-xl font-bold text-royal-900">{studentCount}</p>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <h2 className="text-sm font-semibold text-royal-900">More on SAT ROYAL HUB</h2>
        <div className="mt-3 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {COMING_SOON_ITEMS.map((item) => (
            <div
              key={item.label}
              className="flex flex-col items-center gap-2 rounded-xl bg-white p-4 text-center text-gray-400 shadow-sm"
            >
              <item.icon className="h-6 w-6" />
              <p className="text-sm font-medium">{item.label}</p>
              <span className="rounded-full bg-royal-50 px-2 py-0.5 text-[10px] font-medium text-royal-400">
                Coming soon
              </span>
            </div>
          ))}
        </div>
      </div>

      {!loading && !className && (
        <div className="mt-6 rounded-xl bg-white p-6 shadow-sm">
          <p className="text-sm text-gray-500">
            You haven't been assigned a class yet. Contact your administrator.
          </p>
        </div>
      )}
    </div>
  )
}