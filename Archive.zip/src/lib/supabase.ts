import { createClient } from '@supabase/supabase-js'
import { offlineFetch } from '@/lib/offline-fetch'

const url = import.meta.env.VITE_SUPABASE_URL
const key = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!url || !key) {
  throw new Error('Missing Supabase environment variables. Check .env.local')
}

export const supabase = createClient(url, key, {
  auth: { persistSession: true, autoRefreshToken: true },
  global: { fetch: offlineFetch },
})
